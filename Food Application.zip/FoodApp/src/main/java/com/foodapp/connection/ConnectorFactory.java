package com.foodapp.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectorFactory {
	
	static Connection con=null;
	static String url="jdbc:mysql://localhost:3306/foodapp";
	static String un="root";
	static String pw="Madhan@123";
	
	public static Connection requestConnection() throws ClassNotFoundException,SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection(url,un,pw);
		return con;
	}
	

}
