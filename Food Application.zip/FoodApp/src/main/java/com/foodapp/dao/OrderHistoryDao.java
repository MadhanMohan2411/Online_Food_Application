package com.foodapp.dao;

import java.util.List;

import com.foodapp.dto.OrderHistory;

public interface OrderHistoryDao {
	
	List<OrderHistory> getOrderHistories();
	OrderHistory getOrderHistory(int orderhistory_id);
	public boolean insert(int order_id,int user_id,int TotalAmount,String status);
	public boolean update(OrderHistory oh);
	public boolean delete(int orderhistory_id);

}
