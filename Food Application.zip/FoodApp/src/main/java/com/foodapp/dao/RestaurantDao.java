package com.foodapp.dao;

import java.util.List;

import com.foodapp.dto.Restaurant;

public interface RestaurantDao {
	
	List getrestaurants();
	Restaurant getrestaurant(int restaurant_id);
	public boolean insert(String name,String Cuisine_Type,int Delivery_time,String Address,float ratings,String isActive,String ImagePath);
	public boolean update(Restaurant r);
	public boolean delete(int restauran_id);
	
	//new
	List<Restaurant> getAllRestaurants();



}
