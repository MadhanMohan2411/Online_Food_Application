package com.foodapp.dao;

import java.util.List;

import com.foodapp.dto.order;

public interface orderDao {
	
	List getOrderTables();
	order getOrderTable(int order_id);
	public boolean insert(int user_id,int restaurant_id,int TotalAmount,String status,String payment_mode);
	public boolean update(order ot);
	public boolean delete(int order_id);
	int getLastInsertedOrderId();

}
