package com.foodapp.dao;

import java.util.List;

import com.foodapp.dto.Menu;

public interface menuDao {
	
	List getmenues();
	Menu getmenues(int menu_id);
	public boolean insert(int restaurant_id,String name,String description, int price,String isAvailable, String ImagePath);
	public boolean update(Menu m);
	public boolean delete(int menu_id);
	
	List fetchMenuByRest(int restaurant_id);

}
