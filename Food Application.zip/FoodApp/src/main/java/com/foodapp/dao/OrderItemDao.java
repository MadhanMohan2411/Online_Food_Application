package com.foodapp.dao;

import java.util.List;
import com.foodapp.dto.OrderItems;

public interface OrderItemDao {
    
    // Get all order items
    List<OrderItems> getOrderItemsAll();
    
    // Get order items by order ID
    List<OrderItems> getOrderItemsByOrderId(int orderId);
    
    // Get a single order item by its ID
    OrderItems getOrderItems(int orderitem_id);
    
    // Insert a new order item
    boolean insert(int order_id, int menu_id, int quantity, int ItemTotal);
    
    // Update an existing order items
    boolean update(OrderItems oi);
    
    // Delete an order item by its ID
    boolean delete(int orderitem_id);
}
