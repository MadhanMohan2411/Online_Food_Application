package com.foodapp.dao;

import java.util.List;

import com.foodapp.dto.User;



public interface userDao {
	
	int addUser(User u);
	
	List<User> getusers();
	
	User getUser(int user_id);
	User getuser(String email);
	public boolean insert(String user_name, String email, String password, String address );
	public boolean update(User u);
	public boolean delete(int user_id);
	

}
