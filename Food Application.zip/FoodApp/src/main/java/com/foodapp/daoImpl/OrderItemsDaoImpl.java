package com.foodapp.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.foodapp.connection.ConnectorFactory;
import com.foodapp.dao.OrderItemDao;
import com.foodapp.dto.OrderItems;

public class OrderItemsDaoImpl implements OrderItemDao {
	
	ArrayList<OrderItems> List=null;

	public List <OrderItems> getOrderItemsAll() {
		
		try
		{
			Connection con = ConnectorFactory.requestConnection();
			Statement stmt=con.createStatement();
			String query="select * from orderitems";
			ResultSet res=stmt.executeQuery(query);
			List=new ArrayList<OrderItems>();
			while(res.next()==true)
			{
				int orderitem_id=res.getInt(1);
				int order_id=res.getInt(2);
				int menu_id=res.getInt(3);
				int quantity=res.getInt(4);
				int ItemTotal=res.getInt(5);
				
				OrderItems oi=new OrderItems(orderitem_id,order_id, menu_id, quantity);
				List.add(oi);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return List;
}

@Override
public OrderItems getOrderItems(int orderitem_id) {
	OrderItems oi=null;
	try
	{
		Connection con=ConnectorFactory.requestConnection();
		String query="select * from orderitems where orderitem_id=?";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setInt(1, orderitem_id);
		ResultSet res=pstmt.executeQuery();
		res.next();
		
		oi=new OrderItems(res.getInt(1),res.getInt(2),res.getInt(3),res.getInt(4));
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return oi; 
}

@Override
public boolean insert(int order_id, int menu_id, int quantity, int ItemTotal) {
	int i=0;
	try
	{
		Connection con=ConnectorFactory.requestConnection();
		String query="insert into orderitems(orderitem_id,order_id,menu_id,quantity,ItemTotal) values(?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(query);
		//pstmt.setInt(1,orderitem_id);
		pstmt.setInt(1,order_id);
		pstmt.setInt(2,menu_id);
		pstmt.setInt(3,quantity);
		pstmt.setInt(4,ItemTotal);
		i=pstmt.executeUpdate();
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	if(i==1)
	{
		return true;
	}
	return false;
}

@Override
public boolean update(OrderItems oi) {
	int i=0;
	try
	{
		Connection con=ConnectorFactory.requestConnection();
		String query="update orderitems set ItemTotal=? where orderitem_id=?";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setInt(1, oi.getItemTotal());
		pstmt.setInt(2, oi.getOrderitem_id());
		i=pstmt.executeUpdate();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	if(i==1)
	{
		return true;
	}
	return false;
}

@Override
public boolean delete(int orderitem_id) {
	int i=0;
	try
	{
		Connection con=ConnectorFactory.requestConnection();
		String query="delete from OrderItems where orderitem_id=?";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setInt(1, orderitem_id);
		i=pstmt.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(i==1)
		{
			return true;
		}
		return false;
}

@Override
public java.util.List getOrderItemsByOrderId(int order_id) {
	 List<OrderItems> list = new ArrayList<>();
	    try (Connection con = ConnectorFactory.requestConnection()) {
	        String query = "SELECT * FROM orderitems WHERE order_id = ?";
	        PreparedStatement pstmt = con.prepareStatement(query);
	        pstmt.setInt(1, order_id);
	        ResultSet res = pstmt.executeQuery();

	        while (res.next()) {
	            list.add(new OrderItems(
	                res.getInt("orderitem_id"),
	                res.getInt("order_id"),
	                res.getInt("menu_id"),
	                res.getInt("quantity")
//	                res.getInt("ItemTotal")
	            ));
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return list;
}


}
