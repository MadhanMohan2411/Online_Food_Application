package com.foodapp.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.foodapp.connection.ConnectorFactory;
import com.foodapp.dao.userDao;
import com.foodapp.dto.User;

public class userDaoImpl implements userDao{
	
	ArrayList<User>List=null;
	public List getUsers() {
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			Statement stmt=con.createStatement();
			String query="select * from user";
			ResultSet res=stmt.executeQuery(query);
			List=new ArrayList<User>();
			while(res.next()==true)
			{
				int user_id=res.getInt(1);
				String user_name=res.getString(2);
				String email=res.getString(3);
				String password=res.getString(4);
				String address=res.getString(5);
				User u=new User(user_id,user_name,email,password,address);
				List.add(u);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
			return List;
	}

//	@Override
	public User getUser(int user_id) {
		User u=null;
		try {
			Connection con=ConnectorFactory.requestConnection();
			String query="select * from user where user_id=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1, user_id);
			ResultSet res=pstmt.executeQuery();
			res.next();
			 u=new User(res.getInt(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5));
			
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	//@Override
	public boolean insert(String user_name, String email, String password, String address) {
		int i=0;
		try {
			Connection con=ConnectorFactory.requestConnection();
			String query="insert into user(user_name,email,password,address) values(?,?,?,?)";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1, user_name);
			pstmt.setString(2, email);
			pstmt.setString(3, password);
			pstmt.setString(4, address);
			i=pstmt.executeUpdate();
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		if(i==1)
		{
			return true;
		}
		return false;
	}
	
	

//	@Override
	public boolean update(User u) {
		int i=0;
		try
		{
		Connection con=ConnectorFactory.requestConnection();
		String query="update user set password = ? where user_id = ?";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setString(1, u.getPassword());
		pstmt.setInt(2, u.getUser_id());
		
		i=pstmt.executeUpdate();
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(i==1)
		{
			return true;
		}
		return false;
	}
//
//	@Override
	public boolean delete(int user_id) {
		int i=0;
		try {
			Connection con=ConnectorFactory.requestConnection();
			String query="delete from user where user_id = ?";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1, user_id);
			i=pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		if(i==1)
		{
			return true;
		}
		return false;
	

	
	}

@Override
public java.util.List<User> getusers() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public User getuser(String email) {
	User u=null;
	try {
		Connection con=ConnectorFactory.requestConnection();
		String query="select * from user where email=?";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setString(1, email);
		ResultSet res=pstmt.executeQuery();
		if(res.next()) 
		{
		 u=new User(res.getInt("user_id"),res.getString("user_name"),res.getString("email"),res.getString("password"),res.getString("address"));
		}
		
	} 
	catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return u;
}

//@Override
public int addUser(User u) {
	int i=0;
	try {
		Connection con=ConnectorFactory.requestConnection();
		String query="insert into user(user_name,email,password,address) values(?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setString(1, u.getUser_name());
		pstmt.setString(2, u.getEmail());
		pstmt.setString(3, u.getPassword());
		pstmt.setString(4, u.getAddress());
		i=pstmt.executeUpdate();
		
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	return i;
}

}
