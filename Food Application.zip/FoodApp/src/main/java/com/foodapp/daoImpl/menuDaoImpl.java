package com.foodapp.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.foodapp.connection.ConnectorFactory;
import com.foodapp.dao.menuDao;
import com.foodapp.dto.Menu;
import java.util.List;
public class menuDaoImpl implements menuDao{
	
	ArrayList<Menu> List=null;
	public List getmenues() {
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			Statement stmt=con.createStatement();
			String query="select * from menu";
			ResultSet res=stmt.executeQuery(query);
			List=new ArrayList<Menu>();
			while(res.next()==true)
			{
				int menu_id=res.getInt(1);
				int restaurant_id=res.getInt(2);
				String name=res.getString(3);
				String description=res.getString(4);
				int price=res.getInt(5);
				String isAvailable=res.getString(6);
				String ImagePath=res.getString(7);
				
				Menu m=new Menu(menu_id, restaurant_id, name, description, price, isAvailable, ImagePath);
				List.add(m);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return List;
	}

	@Override
	public Menu getmenues(int menu_id) {
		Menu m=null;
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			String query="select * from menu where menu_id=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1, menu_id);
			ResultSet res=pstmt.executeQuery();
			res.next();
			m=new Menu(res.getInt(1),res.getInt(2),res.getString(3),res.getString(4),res.getInt(5),res.getString(6),res.getString(7));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return m;
	}
	

	@Override
	public boolean insert(int restaurant_id, String name, String description, int price, String isAvailable,
			String ImagePath) {
		int i=0;
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			String query="insert into menu(restaurant_id,name,description,price,isAvailable,ImagePath) values(?,?,?,?,?,?)";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1, restaurant_id);
			pstmt.setString(2, name);
			pstmt.setString(3,description);
			pstmt.setInt(4, price);
			pstmt.setString(5, isAvailable);
			pstmt.setString(6, ImagePath);
			i=pstmt.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(i==1)
		{
			return true;
		}
		return false;
	}
	

	@Override
	public boolean update(Menu m) {
		int i=0;
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			String query="update menu set isAvailable=? where menu_id=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1, m.getIsAvailable());
			pstmt.setInt(2, m.getMenu_id());
			i=pstmt.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(i==1)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean delete(int menu_id) {
		int i=0;
		try
		{
		Connection con=ConnectorFactory.requestConnection();
		String query="delete from menu where menu_id=?";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setInt(1, menu_id);
		i=pstmt.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(i==1)
		{
			return true;
		}
		return false;
	}

	@Override
	public List<Menu> fetchMenuByRest(int restaurant_id) {
        List<Menu> menuList = new ArrayList<>();
        String query = "SELECT * FROM menu WHERE restaurant_id = ?";

        try (Connection conn = ConnectorFactory.requestConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, restaurant_id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Menu menu = new Menu();
                menu.setMenu_id(rs.getInt("menu_id"));
                menu.setRestaurant_id(rs.getInt("restaurant_id"));
                menu.setName(rs.getString("name"));
                menu.setDescription(rs.getString("description"));
                menu.setPrice(rs.getInt("price"));
                menu.setIsAvailable(rs.getString("isAvailable"));
                menu.setImagePath(rs.getString("ImagePath"));
                menuList.add(menu);
            }

            System.out.println("Fetched " + menuList.size() + " menu items for restaurant ID: " + restaurant_id);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return menuList;
    }

    // Other methods (getmenues, insert, update, delete) would be implemented similarly...

}
