package com.foodapp.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import com.foodapp.connection.ConnectorFactory;
import com.foodapp.dao.OrderHistoryDao;
import com.foodapp.dto.OrderHistory;

public class OrderHistoryDaoImpl implements OrderHistoryDao {

    @Override
    public List<OrderHistory> getOrderHistories() {
        List<OrderHistory> orderHistoryList = new LinkedList<>();

        try (Connection con = ConnectorFactory.requestConnection();
             Statement stmt = con.createStatement();
             ResultSet res = stmt.executeQuery("SELECT * FROM orderhistory")) {

            while (res.next()) {
                int orderHistoryId = res.getInt(1);
                int orderId = res.getInt(2);
                int userId = res.getInt(3);
                int totalAmount = res.getInt(4);
                String status = res.getString(5);

                OrderHistory orderHistory = new OrderHistory(orderHistoryId, orderId, userId, totalAmount, status);
                orderHistoryList.add(orderHistory);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return orderHistoryList;
    }

    @Override
    public OrderHistory getOrderHistory(int orderHistoryId) {
        OrderHistory orderHistory = null;

        try (Connection con = ConnectorFactory.requestConnection();
             PreparedStatement pstmt = con.prepareStatement("SELECT * FROM orderhistory WHERE orderhistory_id = ?")) {

            pstmt.setInt(1, orderHistoryId);
            try (ResultSet res = pstmt.executeQuery()) {
                if (res.next()) {
                    orderHistory = new OrderHistory(
                        res.getInt(1),
                        res.getInt(2),
                        res.getInt(3),
                        res.getInt(4),
                        res.getString(5)
                    );
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return orderHistory;
    }

    @Override
    public boolean insert(int orderId, int userId, int totalAmount, String status) {
        String query = "INSERT INTO orderhistory (order_id, user_id, TotalAmount, status) VALUES (?, ?, ?, ?)";

        try (Connection con = ConnectorFactory.requestConnection();
             PreparedStatement pstmt = con.prepareStatement(query)) {

            pstmt.setInt(1, orderId);
            pstmt.setInt(2, userId);
            pstmt.setInt(3, totalAmount);
            pstmt.setString(4, status);

            return pstmt.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean update(OrderHistory orderHistory) {
        String query = "UPDATE orderhistory SET status = ? WHERE orderhistory_id = ?";

        try (Connection con = ConnectorFactory.requestConnection();
             PreparedStatement pstmt = con.prepareStatement(query)) {

            pstmt.setString(1, orderHistory.getStatus());
            pstmt.setInt(2, orderHistory.getOrderhistory_id());

            return pstmt.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean delete(int orderHistoryId) {
        String query = "DELETE FROM orderhistory WHERE orderhistory_id = ?";

        try (Connection con = ConnectorFactory.requestConnection();
             PreparedStatement pstmt = con.prepareStatement(query)) {

            pstmt.setInt(1, orderHistoryId);

            return pstmt.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
