package com.foodapp.daoImpl;

import java.util.HashMap;

import com.foodapp.dto.CartItem;

public class Cart {
	
	private HashMap<Integer, CartItem> items;
	
	public Cart()
	{
		this.items=new HashMap<>();
	}
	
	//Add item to the cart
	public void addItem(CartItem item)
	{
		if(items.containsKey(item.getMenu_id()))
		{
			CartItem existingItem=items.get(item.getMenu_id());
			existingItem.setQuantity(existingItem.getQuantity()+item.getQuantity());
		}
		else
		{
			items.put(item.getMenu_id(), item);
		}
	}
	
	//Remove item from the cart
	public void removeItem(int menu_id)
	{
		items.remove(menu_id);
	}
	
	//Update the quantity of item in the cart
	public void updateItemquantity(int menu_id,int quantity)
	{
		if(items.containsKey(menu_id))
		{
			CartItem item=items.get(menu_id);
			item.setQuantity(quantity);
		}
	}
	
	//Get all items in the cart
	public HashMap<Integer, CartItem> getItems()
	{
		return items;
	}
	
	//Get the total price of the cart
	public int getTotal()
	{
		int total=0;
		for(CartItem item : items.values())
		{
			total+=item.getSubtotal();
		}
		return total;
	}
	
	// Clear the cart
	public void clearCart()
	{
		items.clear();
	}

}







