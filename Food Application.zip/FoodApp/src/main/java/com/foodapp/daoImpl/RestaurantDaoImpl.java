package com.foodapp.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.foodapp.connection.ConnectorFactory;
import com.foodapp.dao.RestaurantDao;
import com.foodapp.dto.Restaurant;

public class RestaurantDaoImpl implements RestaurantDao{
	
	ArrayList<Restaurant> List=null;
	public List getrestaurants() {
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			Statement stmt=con.createStatement();
			String query="select * from restaurant";
			ResultSet res=stmt.executeQuery(query);
			List=new ArrayList<Restaurant>();
			while(res.next()==true)
			{
				int restaurant_id=res.getInt(1);
				String name=res.getString(2);
				String Cuisine_Type=res.getString(3);
				int Delivery_time=res.getInt(4);
				String Address=res.getString(5);
				float ratings=res.getFloat(6);
				String isActive=res.getString(7);
				String ImagePath=res.getString(8);
				
				Restaurant r=new Restaurant(restaurant_id, name, Cuisine_Type, Delivery_time, Address, ratings, isActive, ImagePath);
				List.add(r);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return List;
	}

	@Override
	public Restaurant getrestaurant(int restaurant_id) {
		Restaurant r=null;
		try {
			Connection con=ConnectorFactory.requestConnection();
			String query="select * from restaurant where restaurant_id=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1, restaurant_id);
			ResultSet res=pstmt.executeQuery();
			res.next();	
			r=new Restaurant(res.getInt(1),res.getString(2),res.getString(3),res.getInt(4),res.getString(5),res.getFloat(6),res.getString(7),res.getString(8));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return r;
	}

	@Override
	public boolean insert(String name, String Cuisine_Type, int Delivery_time, String Address, float ratings,
			String isActive, String ImagePath) {
		int i=0;
		try {
		Connection con=ConnectorFactory.requestConnection();
		String query="insert into restaurant(name,Cuisine_Type,Delivery_time,Address,ratings,isActive,ImagePath) values(?,?,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setString(1, name);
		pstmt.setString(2, Cuisine_Type);
		pstmt.setInt(3, Delivery_time);
		pstmt.setString(4, Address);
		pstmt.setFloat(5,ratings);
		pstmt.setString(6, isActive);
		pstmt.setString(7, ImagePath);
		i=pstmt.executeUpdate();
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(i==1)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean update(Restaurant r) {
		int i=0;
		try {
			Connection con=ConnectorFactory.requestConnection();
			String query="update restaurant set isActive=? where restaurant_id=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1, r.getIsActive());
			pstmt.setInt(2, r.getRestaurant_id());
			i=pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		if(i==1)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean delete(int restauran_id) {
		int i=0;
		try
		{
		Connection con=ConnectorFactory.requestConnection();
		String query="delete from restaurant where restaurant_id=?";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setInt(1, restauran_id);
		i=pstmt.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(i==1)
		{
			return true;
		}
		return false;
	}
	
	//new
	@Override
	public List<Restaurant> getAllRestaurants() {
	    List<Restaurant> allRestaurants = new ArrayList<>();
	    try {
	        // Obtain the connection using the ConnectorFactory
	        Connection con = ConnectorFactory.requestConnection();
	        
	        // Query to fetch all restaurants
	        String query = "SELECT * FROM restaurant";
	        PreparedStatement pstmt = con.prepareStatement(query);
	        ResultSet rs = pstmt.executeQuery();

	        // Iterate through the result set and populate the list
	        while (rs.next()) {
	            Restaurant restaurant = new Restaurant(
	                rs.getInt("restaurant_id"),
	                rs.getString("name"),
	                rs.getString("Cuisine_Type"),
	                rs.getInt("Delivery_time"),
	                rs.getString("Address"),
	                rs.getFloat("ratings"),
	                rs.getString("isActive"),
	                rs.getString("ImagePath")
	            );
	            allRestaurants.add(restaurant);
	        }

	        // Close the connection
	        con.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return allRestaurants;
	}



	

}
