package com.foodapp.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.foodapp.connection.ConnectorFactory;
import com.foodapp.dao.orderDao;
import com.foodapp.dto.order;

public class orderDaoImpl implements orderDao {
	
	ArrayList<order> List=null;

	public List getOrderTables() {
		
		try
		{
			Connection con = ConnectorFactory.requestConnection();
			Statement stmt=con.createStatement();
			String query="select * from ordertable";
			ResultSet res=stmt.executeQuery(query);
			List=new ArrayList<order>();
			while(res.next()==true)
			{
				int order_id=res.getInt(1);
				int user_id=res.getInt(2);
				int restaurant_id=res.getInt(3);
				int TotalAmount=res.getInt(4);
				String status=res.getString(5);
				String paymentMode=res.getString(6);
				
				order ot=new order(order_id, user_id, restaurant_id, TotalAmount, status, paymentMode);
				List.add(ot);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return List;
	}

	@Override
	public order getOrderTable(int order_id) {
		order ot=null; 
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			String query="select * from ordertable where order_id=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1, order_id);
			ResultSet res=pstmt.executeQuery();
			res.next();
			
			ot=new order(res.getInt(1),res.getInt(2),res.getInt(3),res.getInt(4),res.getString(5),res.getString(4));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ot; 
	}

	@Override
	public boolean insert(int user_id, int restaurant_id, int TotalAmount, String status, String payment_mode) {
		int i=0;
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			String query="insert into ordertable(user_id,restaurant_id,TotalAmount,status,payment_mode) values(?,?,?,?,?)";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1,user_id);
			pstmt.setInt(2,restaurant_id);
			pstmt.setInt(3,TotalAmount);
			pstmt.setString(4,status);
			pstmt.setString(5,payment_mode);
			i=pstmt.executeUpdate();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(i==1)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean update(order ot) {
		int i=0;
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			String query="update OrderTable set status=? where order_id=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1, ot.getStatus());
			pstmt.setInt(2, ot.getOrder_id());
			i=pstmt.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(i==1)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean delete(int order_id) {
		int i=0;
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			String query="delete from OrderTable where order_id=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1, order_id);
			i=pstmt.executeUpdate();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			if(i==1)
			{
				return true;
			}
			return false;
	}

	@Override
	public int getLastInsertedOrderId() {
		int lastOrderId=0;
		try
		{
			Connection con=ConnectorFactory.requestConnection();
			String query="select MAX(order_id) from ordertable";
			PreparedStatement pstmt=con.prepareStatement(query);
			ResultSet res=pstmt.executeQuery();
			if(res.next())
			{
				lastOrderId=res.getInt(1);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return lastOrderId;
	}

}
