package com.foodapp.dto;

public class Menu {
	
	private int menu_id;
	private int restaurant_id;
	private String name;
	private String description;
	private int price;
	private String isAvailable;
	private String ImagePath;
	
	
	public int getMenu_id() {
		return menu_id;
	}
	public void setMenu_id(int menu_id) {
		this.menu_id = menu_id;
	}
	public int getRestaurant_id() {
		return restaurant_id;
	}
	public void setRestaurant_id(int restaurant_id) {
		this.restaurant_id = restaurant_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getIsAvailable() {
		return isAvailable;
	}
	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}
	public String getImagePath() {
		return ImagePath;
	}
	public void setImagePath(String imagePath) {
		this.ImagePath = imagePath;
	}
	public Menu() {
		super();
	}
	public Menu(int menu_id, int restaurant_id, String name, String description, int price, String isAvailable,
			String imagePath) {
		super();
		this.menu_id = menu_id;
		this.restaurant_id = restaurant_id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.isAvailable = isAvailable;
		ImagePath = imagePath;
	}
	@Override
	public String toString() {
		return "menu [menu_id=" + menu_id + ", restaurant_id=" + restaurant_id + ", name=" + name + ", description="
				+ description + ", price=" + price + ", isAvailable=" + isAvailable + ", ImagePath=" + ImagePath + "]";
	}

}
