package com.foodapp.dto;

public class OrderHistory {
	
	private int orderhistory_id;
	private int order_id;
	private int user_id;
	private int TotalAmount;
	private String status;
	private int orderDate;
	public int getOrderhistory_id() {
		return orderhistory_id;
	}
	public void setOrderhistory_id(int orderhistory_id) {
		this.orderhistory_id = orderhistory_id;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getTotalAmount() {
		return TotalAmount;
	}
	public void setTotalAmount(int totalAmount) {
		TotalAmount = totalAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(int orderDate) {
		this.orderDate = orderDate;
	}
	public OrderHistory() {
		super();
	}
	public OrderHistory(int orderhistory_id, int order_id, int user_id, int totalAmount, String status) {
		super();
		this.orderhistory_id = orderhistory_id;
		this.order_id = order_id;
		this.user_id = user_id;
		TotalAmount = totalAmount;
		this.status = status;
//		this.orderDate = orderDate;
	}
	@Override
	public String toString() {
		return "OrderHistory [orderhistory_id=" + orderhistory_id + ", order_id=" + order_id + ", user_id=" + user_id
				+ ", TotalAmount=" + TotalAmount + ", status=" + status + ", orderDate=" + orderDate + "]";
	}

}
