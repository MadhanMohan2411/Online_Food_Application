package com.foodapp.dto;

public class User {
	
	private int user_id;
	private String user_name;
	private String email;
	private String password;
	private String address;
	private String createDate;
	private String latLoginDate;
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getLatLoginDate() {
		return latLoginDate;
	}
	public void setLatLoginDate(String latLoginDate) {
		this.latLoginDate = latLoginDate;
	}
	public User(int user_id,String user_name, String email, String password, String address 
			) {
		super();
		this.user_id = user_id;
		this.user_name = user_name;
		this.email = email;
		this.password = password;
		this.address = address;
//		this.createDate = createDate;
//		this.latLoginDate = latLoginDate;
	}
	public User() {
		super();
	}
	public User(String user_name, String email, String password, String address, String createDate,
			String latLoginDate) {
		super();
		this.user_name = user_name;
		this.email = email;
		this.password = password;
		this.address = address;
		this.createDate = createDate;
		this.latLoginDate = latLoginDate;
	}
	
	
	public User(String user_name, String email, String password, String address) {
		super();
		this.user_name = user_name;
		this.email = email;
		this.password = password;
		this.address = address;
	}
	@Override
	public String toString() {
		return "user [user_id=" + user_id + ", user_name=" + user_name + ", email=" + email + ", password="
				+ password + ", address=" + address + ", createDate=" + createDate + ", latLoginDate="
				+ latLoginDate + "]";
	}

}
