package com.foodapp.dto;

public class CartItem {
    
    private int menu_id;
    private int restaurant_id;
    private String name;
    private int price;
    private int quantity;
    private int subtotal;

    public CartItem(int menu_id, int restaurant_id, String name, int price, int quantity) {
        this.menu_id = menu_id;
        this.restaurant_id = restaurant_id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.subtotal=price*quantity;
        updateSubtotal(); // Automatically calculate subtotal
    }

    public CartItem() {
        // Default constructor
    }

    public int getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(int menu_id) {
        this.menu_id = menu_id;
    }
    
    public int getRestaurant_id() {
        return restaurant_id;
    }

    public void setRestaurant_id(int restaurant_id) {
        this.restaurant_id = restaurant_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
        updateSubtotal(); // Recalculate subtotal when price is set
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity > 0) {
            this.quantity = quantity;
            updateSubtotal(); // Recalculate subtotal when quantity is set
        } else {
            throw new IllegalArgumentException("Quantity must be greater than 0");
        }
    }

    public int getSubtotal() {
        return subtotal;
    }

    private void updateSubtotal() {
        this.subtotal = this.price * this.quantity;
    }

    @Override
    public String toString() {
        return "CartItem [menu_id=" + menu_id + ", restaurant_id=" + restaurant_id + ", name=" + name + ", price="
                + price + ", quantity=" + quantity + ", subtotal=" + subtotal + "]";
    }
}
