package com.foodapp.dto;

public class Restaurant {
	
	private int restaurant_id;
	private String name;
	private String Cuisine_Type;
	private int Delivery_time;
	private String Address;
	private float ratings;
	private String isActive;
	private String ImagePath;
	public Restaurant(int restaurant_id, String name, String cuisine_Type, int delivery_time, String address,
			float ratings, String isActive, String imagePath) {
		super();
		this.restaurant_id = restaurant_id;
		this.name = name;
		Cuisine_Type = cuisine_Type;
		Delivery_time = delivery_time;
		Address = address;
		this.ratings = ratings;
		this.isActive = isActive;
		ImagePath = imagePath;
	}
	public Restaurant(String name, String cuisine_Type, int delivery_time, String address, float ratings,
			String isActive, String imagePath) {
		super();
		this.name = name;
		Cuisine_Type = cuisine_Type;
		Delivery_time = delivery_time;
		Address = address;
		this.ratings = ratings;
		this.isActive = isActive;
		ImagePath = imagePath;
	}
	public Restaurant() {
		super();
	}
	public int getRestaurant_id() {
		return restaurant_id;
	}
	public void setRestaurant_id(int restaurant_id) {
		this.restaurant_id = restaurant_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCuisine_Type() {
		return Cuisine_Type;
	}
	public void setCuisine_Type(String cuisine_Type) {
		Cuisine_Type = cuisine_Type;
	}
	public int getDelivery_time() {
		return Delivery_time;
	}
	public void setDelivery_time(int delivery_time) {
		Delivery_time = delivery_time;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public float getRatings() {
		return ratings;
	}
	public void setRatings(float ratings) {
		this.ratings = ratings;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getImagePath() {
		return ImagePath;
	}
	public void setImagePath(String imagePath) {
		ImagePath = imagePath;
	}
	@Override
	public String toString() {
		return "restaurant [restaurant_id=" + restaurant_id + ", name=" + name + ", Cuisine_Type=" + Cuisine_Type
				+ ", Delivery_time=" + Delivery_time + ", Address=" + Address + ", ratings=" + ratings + ", isActive="
				+ isActive + ", ImagePath=" + ImagePath + "]";
	}

}
