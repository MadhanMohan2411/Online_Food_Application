package com.foodapp.dto;

public class order {
	
	private int order_id;
	private int user_id;
	private int restaurant_id;
	private int TotalAmount;
	private String status;
	private String payment_mode;
	
	
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getRestaurant_id() {
		return restaurant_id;
	}
	public void setRestaurant_id(int restaurant_id) {
		this.restaurant_id = restaurant_id;
	}
	public int getTotalAmount() {
		return TotalAmount;
	}
	public void setTotalAmount(int totalAmount) {
		TotalAmount = totalAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPayment_mode() {
		return payment_mode;
	}
	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}
	public order() {
		super();
	}
	public order(int order_id, int user_id, int restaurant_id, int totalAmount, String status,
			String payment_mode) {
		super();
		this.order_id = order_id;
		this.user_id = user_id;
		this.restaurant_id = restaurant_id;
		TotalAmount = totalAmount;
		this.status = status;
		this.payment_mode = payment_mode;
	}
	@Override
	public String toString() {
		return "order [order_id=" + order_id + ", user_id=" + user_id + ", restaurant_id=" + restaurant_id
				+ ", TotalAmount=" + TotalAmount + ", status=" + status + ", payment_mode=" + payment_mode + "]";
	}
	

}
