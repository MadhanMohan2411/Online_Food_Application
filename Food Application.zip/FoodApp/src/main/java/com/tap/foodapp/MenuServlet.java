package com.tap.foodapp;

import java.io.IOException;
import java.util.List;

import com.foodapp.daoImpl.menuDaoImpl;
import com.foodapp.dto.Menu;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Menu")
public class MenuServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String str = req.getParameter("restId");

        // Validate if the `restId` parameter is present
        if (str == null || str.isEmpty()) {
            System.out.println("Error: Restaurant ID is missing");
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Restaurant ID is required");
            return;
        }

        try {
            // Parse the restaurant ID
            int restaurant_id = Integer.parseInt(str);
            System.out.println("Restaurant ID received: " + restaurant_id);

            // Fetch menu items
            menuDaoImpl md = new menuDaoImpl();
            List<Menu> menuList = md.fetchMenuByRest(restaurant_id);

            if (menuList == null) {
                System.out.println("Error: fetchMenuByRest returned NULL");
            } else {
                System.out.println("Fetched " + menuList.size() + " menu items for restaurant ID: " + restaurant_id);
            }

            // Set attributes for JSP
            HttpSession session = req.getSession();
            session.setAttribute("menuItems", menuList);
            session.setAttribute("restaurant_id", restaurant_id);

            // Forward to JSP
            RequestDispatcher dispatcher = req.getRequestDispatcher("Menu.jsp");
            dispatcher.forward(req, resp);

        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid restaurant ID format");
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid restaurant ID format");
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("Error: Unexpected exception occurred");
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An unexpected error occurred");
            e.printStackTrace();
        }
    }
}
