package com.tap.foodapp;

import java.io.IOException;

import com.foodapp.daoImpl.Cart;
import com.foodapp.dto.CartItem;
import com.foodapp.dto.Menu;
import com.foodapp.dao.menuDao;
import com.foodapp.daoImpl.menuDaoImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Cart")
public class CartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Cart cart = (Cart) session.getAttribute("cart");

        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }

        String action = req.getParameter("action");
        try
        {
            if ("add".equals(action)) {
                addItemToCart(req, cart);
            } else if ("update".equals(action)) {
                updateCartItem(req, cart);
            } else if ("remove".equals(action)) {
                removeItemFromCart(req, cart);
            } else {
                throw new IllegalArgumentException("Invalid action: " + action);
            }

            session.setAttribute("cart", cart);
            resp.sendRedirect("Cart.jsp");
        }
        catch (Exception e)
        {
            e.printStackTrace();
            req.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
            req.getRequestDispatcher("error.jsp").forward(req, resp);
        }
    }

    private void addItemToCart(HttpServletRequest req, Cart cart) throws Exception {
        int menuId = Integer.parseInt(req.getParameter("menuid"));
        
        	System.out.println("--------------"+menuId);
        	HttpSession session=req.getSession();
        	session.setAttribute("menuid",menuId );
        	
        int quantity = Integer.parseInt(req.getParameter("quantity"));

        menuDao menuDao = new menuDaoImpl();
        Menu menuItem = menuDao.getmenues(menuId);

        if (menuItem == null) {
            throw new IllegalArgumentException("Menu item not found for ID: " + menuId);
        }

        CartItem item = new CartItem(
            menuItem.getMenu_id(),
            menuItem.getRestaurant_id(),
            menuItem.getName(),
            menuItem.getPrice(),
           
          //  menuItem.getPrice() * quantity,
            quantity
        );

        cart.addItem(item);
    }

    private void updateCartItem(HttpServletRequest req, Cart cart) {
        int menuId = Integer.parseInt(req.getParameter("itemid"));
        int quantity = Integer.parseInt(req.getParameter("quantity"));
        
        HttpSession session=req.getSession();
        session.setAttribute("quantity", quantity);
        if (quantity > 0) {
            cart.updateItemquantity(menuId, quantity);
        } else {
            throw new IllegalArgumentException("Quantity cannot be zero or negative.");
        }
    }

    private void removeItemFromCart(HttpServletRequest req, Cart cart) {
        int menuId = Integer.parseInt(req.getParameter("itemid"));
        cart.removeItem(menuId);
    }
}