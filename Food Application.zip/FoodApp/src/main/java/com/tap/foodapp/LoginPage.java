package com.tap.foodapp;

import java.io.IOException;

import com.foodapp.dao.userDao;
import com.foodapp.daoImpl.userDaoImpl;
import com.foodapp.dto.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginPage")
public class LoginPage extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        userDao ud = new userDaoImpl();
        User user = ud.getuser(email);

        if (user != null) {
            if (password.equals(user.getPassword())) {
                HttpSession session = req.getSession();
                session.setAttribute("User", user);
                session.setAttribute("user_id", user.getUser_id());
                resp.sendRedirect("Home");
            } else {
                resp.sendRedirect("failure.html");
            }
        } else {
            resp.sendRedirect("Register.html");
        }
    }
}
