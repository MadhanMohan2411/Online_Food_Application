package com.tap.foodapp;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.foodapp.dao.OrderItemDao;
import com.foodapp.daoImpl.OrderItemsDaoImpl;
import com.foodapp.dto.OrderItems;

@WebServlet("/ViewOrderItems")
public class ViewServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private OrderItemDao orderItemDAO;

    public ViewServlet() {
        super();
        orderItemDAO = new OrderItemsDaoImpl(); // Use interface type for flexibility
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Get the orderId from the request parameter
        String orderIdParam = request.getParameter("orderId");
        int orderId;

        try {
            orderId = Integer.parseInt(orderIdParam); // Parse orderId
        } catch (NumberFormatException e) {
            // Redirect with error if the orderId is invalid
            response.sendRedirect("orderHistory.jsp?error=Invalid Order ID");
            return;
        }

        try {
            // Fetch the list of OrderItems for the provided orderId
            List<OrderItems> orderItems = orderItemDAO.getOrderItemsByOrderId(orderId);

            if (orderItems != null && !orderItems.isEmpty()) {
                // Store the order items in the session
                HttpSession session = request.getSession();
                session.setAttribute("orderItems", orderItems);

                // Redirect to a JSP page that will display the order items
                response.sendRedirect("OrderItemsView.jsp");
 //               response.sendRedirect("OrderConfirmation.jsp");
                
            } else {
                // Redirect back with an error message if no items are found
                response.sendRedirect("orderHistory.jsp?error=No items found for this order");
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Redirect back with a generic error message
            response.sendRedirect("orderHistory.jsp?error=Unable to fetch order items");
        }
    }
}
