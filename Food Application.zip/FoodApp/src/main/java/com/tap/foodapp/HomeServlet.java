package com.tap.foodapp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.foodapp.daoImpl.RestaurantDaoImpl;
import com.foodapp.dto.Restaurant;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Home")
public class HomeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	
    	System.out.println("home Servlet called");
    	
    	RestaurantDaoImpl restaurantDao=new RestaurantDaoImpl();
    	
    	List<Restaurant> allRestaurants=restaurantDao.getAllRestaurants();
    	
    	req.setAttribute("restaurants", allRestaurants);
    	
    	RequestDispatcher rd=req.getRequestDispatcher("HomeMain.jsp");
    	rd.forward(req, resp);
    	
    }
}
