package com.tap.foodapp;

import java.io.IOException;

import com.foodapp.daoImpl.OrderHistoryDaoImpl;
import com.foodapp.daoImpl.OrderItemsDaoImpl;
import com.foodapp.daoImpl.orderDaoImpl;
import com.foodapp.dto.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class ConfirmOrderServlets
 */
@WebServlet("/ConfirmOrderServlets")
public class ConfirmOrderServlets extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        try {
            // Retrieve user session details
            User currentUser = (User) session.getAttribute("User");
            if (currentUser == null) {
                request.setAttribute("errorMessage", "User not found. Please log in.");
                request.getRequestDispatcher("Login.jsp").forward(request, response);
                return;
            }

            // Retrieve parameters and session attributes
            Integer restaurant_id = (Integer) session.getAttribute("restaurant_id");
            Integer menu_id = (Integer) session.getAttribute("menuid");
            Integer quantity = (Integer) session.getAttribute("quantity");
            String subtotal = request.getParameter("TotalAmount");
            String address = request.getParameter("address");
            String payment_mode = request.getParameter("payment_mode");
            String orderDate = request.getParameter("orderDate");

            // Validate inputs
            if (restaurant_id == null || menu_id == null || quantity == null || subtotal == null 
                    || address == null || payment_mode == null || orderDate == null) {
                request.setAttribute("errorMessage", "Some fields are missing. Please try again.");
                request.getRequestDispatcher("OrderConfirmation.jsp").forward(request, response);
                return;
            }

            int TotalAmount = Integer.parseInt(subtotal);
            int user_id = currentUser.getUser_id();

            // Insert order details
            orderDaoImpl orderDao = new orderDaoImpl();
            boolean orderInserted = orderDao.insert(user_id, restaurant_id, TotalAmount, "Processing", payment_mode);

            if (orderInserted) {
                int order_id = orderDao.getLastInsertedOrderId();

                // Insert order items
                OrderItemsDaoImpl orderItemsDao = new OrderItemsDaoImpl();
                boolean orderItemInserted = orderItemsDao.insert(order_id, menu_id, quantity, TotalAmount);

                // Insert order history
                OrderHistoryDaoImpl orderHistoryDao = new OrderHistoryDaoImpl();
                boolean orderHistoryInserted = orderHistoryDao.insert(order_id, user_id, TotalAmount, "Processing");

                if (orderItemInserted && orderHistoryInserted) {
                    // Pass order details to OrderConfirmation.jsp
                    request.setAttribute("order_id", order_id);
                    request.setAttribute("totalAmount", TotalAmount);
                    request.setAttribute("address", address);
                    request.setAttribute("payment_mode", payment_mode);

                    // Forward to OrderConfirmation.jsp
                    request.getRequestDispatcher("OrderConfirmation.jsp").forward(request, response);
                } else {
                    request.setAttribute("errorMessage", "Failed to save order items or history.");
                    request.getRequestDispatcher("OrderConfirmation.jsp").forward(request, response);
                }
            } else {
                request.setAttribute("errorMessage", "Failed to place the order.");
                request.getRequestDispatcher("OrderConfirmation.jsp").forward(request, response);
            }
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid numeric input. Please try again.");
            request.getRequestDispatcher("OrderConfirmation.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("errorMessage", "An unexpected error occurred. Please try again.");
            request.getRequestDispatcher("OrderConfirmation.jsp").forward(request, response);
        }
    }
}
