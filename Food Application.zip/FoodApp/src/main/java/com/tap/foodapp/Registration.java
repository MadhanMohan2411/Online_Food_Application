package com.tap.foodapp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.foodapp.dao.userDao;
import com.foodapp.daoImpl.userDaoImpl;
import com.foodapp.dto.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/RegistrationServlet")
public class Registration extends HttpServlet {

    

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");  
        String address = req.getParameter("address");

      
        

        // Validate password and confirmPassword
        if (password.equals(confirmPassword)) {
            
        	User u=new User(name,email,password,address);
        	userDao ud=new userDaoImpl();
        	
        	int k=ud.addUser(u);
        	if(k==1)
        	{
        		resp.sendRedirect("registrationSuccess.html");
        	}
        	else
        	{
        		resp.sendRedirect("registrationFailed.html");
        	}
        	
        }
        else
        {
        	resp.sendRedirect("passwordMismatch.html");
        }

        
    }
}
