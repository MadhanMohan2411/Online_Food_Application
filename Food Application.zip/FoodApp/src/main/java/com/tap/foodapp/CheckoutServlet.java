package com.tap.foodapp;

import java.io.IOException;

//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;

import com.foodapp.dao.orderDao;
import com.foodapp.daoImpl.orderDaoImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Checkout")
public class CheckoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Handles POST requests from Checkout.jsp
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set encoding
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        // Retrieve form parameters
        String address = request.getParameter("address");
        String paymentMode = request.getParameter("paymentMode");

        // Validate inputs
        if (address == null || address.trim().isEmpty() || paymentMode == null || paymentMode.trim().isEmpty()) {
            // Redirect back to Checkout.jsp with an error message
            request.setAttribute("errorMessage", "All fields are required. Please fill in all the details.");
            request.getRequestDispatcher("Checkout.jsp").forward(request, response);
            return;
        }

        // Example values for demonstration purposes
        int userId = 1; // Assume user is logged in and you have user_id
        int restaurantId = 101; // Example restaurant ID
        int totalAmount = 500; // Assume a total amount is calculated

        // Save order details using DAO
        orderDao orderDao = new orderDaoImpl();
        boolean isOrderInserted = orderDao.insert(userId, restaurantId, totalAmount, "Pending", paymentMode);

        // Redirect based on the result of the operation
        if (isOrderInserted) {
            // Success: Redirect to an Order Confirmation page
            request.setAttribute("message", "Order placed successfully!");
  //          request.getRequestDispatcher("OrderItemsView.jsp").forward(request, response);
            request.getRequestDispatcher("OrderConfirmation.jsp").forward(request, response);
        } else {
            // Failure: Show error on the checkout page
            request.setAttribute("errorMessage", "Failed to place the order. Please try again.");
            request.getRequestDispatcher("Checkout.jsp").forward(request, response);
        }
    }

    // Handles GET requests
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Redirect to the Checkout.jsp form
        response.sendRedirect(request.getContextPath() + "/Checkout.jsp");
    }
}
